package fr.upem.captcha.images.panneau;

import fr.upem.captcha.images.Theme;

/**
 * Panneau Class
 * It's a global theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class Panneau extends Theme {
}
