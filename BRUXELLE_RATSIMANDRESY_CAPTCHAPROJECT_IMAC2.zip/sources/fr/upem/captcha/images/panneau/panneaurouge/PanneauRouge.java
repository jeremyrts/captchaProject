package fr.upem.captcha.images.panneau.panneaurouge;

import fr.upem.captcha.images.Theme;

/**
 * PanneauRouge Class
 * It's a level 1 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class PanneauRouge extends Theme {
}
