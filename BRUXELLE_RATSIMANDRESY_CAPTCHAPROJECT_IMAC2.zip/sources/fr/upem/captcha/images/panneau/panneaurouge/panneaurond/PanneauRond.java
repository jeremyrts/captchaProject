package fr.upem.captcha.images.panneau.panneaurouge.panneaurond;

import fr.upem.captcha.images.Theme;

/**
 * PanneauRond Class
 * It's a level 2 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class PanneauRond extends Theme {
}
