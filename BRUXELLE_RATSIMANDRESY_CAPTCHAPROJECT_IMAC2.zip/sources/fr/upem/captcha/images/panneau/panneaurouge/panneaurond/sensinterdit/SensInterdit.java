package fr.upem.captcha.images.panneau.panneaurouge.panneaurond.sensinterdit;

import fr.upem.captcha.images.Theme;

/**
 * SensInterdit Class
 * It's a level 3 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class SensInterdit extends Theme {
}
