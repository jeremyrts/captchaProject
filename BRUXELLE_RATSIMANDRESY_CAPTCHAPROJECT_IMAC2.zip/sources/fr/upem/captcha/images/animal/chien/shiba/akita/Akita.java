package fr.upem.captcha.images.animal.chien.shiba.akita;

import fr.upem.captcha.images.Theme;

/**
 * Akita Class
 * It's a level 3 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class Akita extends Theme {
}
