package fr.upem.captcha.images.animal.chien.shiba;

import fr.upem.captcha.images.Theme;

/**
 * Shiba Class
 * It's a level 2 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class Shiba extends Theme {
}
