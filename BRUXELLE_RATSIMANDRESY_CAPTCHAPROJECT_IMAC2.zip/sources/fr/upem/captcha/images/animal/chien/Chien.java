package fr.upem.captcha.images.animal.chien;

import fr.upem.captcha.images.Theme;

/**
 * Chien Class
 * It's a level 1 theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class Chien extends Theme {

}
