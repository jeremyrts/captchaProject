package fr.upem.captcha.images.animal;

import fr.upem.captcha.images.Theme;

/**
 * Animal Class
 * It's a global theme.
 * 
 * @author Jeremy Ratsimandresy
 * @author Julian Bruxelle
 */

public class Animal extends Theme {
}
