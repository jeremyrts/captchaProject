package fr.upem.captcha;

public enum Themes {
	panneau,
	voiture;
}
